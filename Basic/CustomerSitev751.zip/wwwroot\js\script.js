﻿
const myModal = new bootstrap.Modal('#myModal');

setTimeout(() => {
    myModal.hide();
},1000);

//document.querySelector('.btn-close').addEventListener('click', () => {
//    myModal.hide();
//});